class Client {
    private String nom;
    private String ville;

    public Client(String nom, String ville) {
        this.nom = nom;
        this.ville = ville;
    }

    public String getNom() {
        return nom;
    }

    public String getVille() {
        return ville;
    }
}
